# About Me and my application
## My name is Neelketu Kumar Singh.
   from Oriental College Of Technology.
   Semester- fifth.

Smartinternz Dashboard Link- https://smartinternz.com/Student/dashboard

Google Developer Profile Link-  https://g.dev/neelketu
Git repository link-  https://github.com/smartinternz02/SPSGP-104185-Virtual-Internship---Android-Application-Development-Using-Kotlin
Project - Grocery Android App
This Project is a part of Google Supported Virtual Internship - Android App Development Using Kotlin.

## why this app

As we can't remember everything, users frequently forget to buy the things they want to buy. However,
with the assistance of this app, you can make a list of the groceries you intend to buy so that you don't forget anything.

## thank you for giving me great opportunity for this application

